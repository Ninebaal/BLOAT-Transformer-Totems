
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bloattransformertotems.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.bloattransformertotems.item.GraniteTotemItem;
import net.mcreator.bloattransformertotems.item.DioriteTotemItem;
import net.mcreator.bloattransformertotems.item.CobblestoneTotemItem;
import net.mcreator.bloattransformertotems.item.AndesiteTotemItem;
import net.mcreator.bloattransformertotems.BloatTransformerTotemsMod;

public class BloatTransformerTotemsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BloatTransformerTotemsMod.MODID);
	public static final RegistryObject<Item> COBBLESTONE_TOTEM = REGISTRY.register("cobblestone_totem", () -> new CobblestoneTotemItem());
	public static final RegistryObject<Item> ANDESITE_TOTEM = REGISTRY.register("andesite_totem", () -> new AndesiteTotemItem());
	public static final RegistryObject<Item> DIORITE_TOTEM = REGISTRY.register("diorite_totem", () -> new DioriteTotemItem());
	public static final RegistryObject<Item> GRANITE_TOTEM = REGISTRY.register("granite_totem", () -> new GraniteTotemItem());
	// Start of user code block custom items
	// End of user code block custom items
}
